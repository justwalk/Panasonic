define([
  'jquery',
  'underscore',
  'backbone'
], function($, _, Backbone){

  return {};
});

define(function(require){
  var $ = require('jquery');
  var _ = require('underscore');
  var Backbone = require('backbone');

  return {};
});