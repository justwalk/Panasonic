define(['underscore', 'backbone'], function(_, Backbone) {
  var Directory = Backbone.Model.extend({
    urlRoot: 'directory',
    idAttribute: 'ID',
    defaults: {
      Server: 0,
      Path: '',
      Type: ''
    }
  });
  return Directory;
});