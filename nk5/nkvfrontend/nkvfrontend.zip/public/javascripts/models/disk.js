define(['underscore', 'backbone'], function(_, Backbone) {
    var Disk = Backbone.Model.extend({
        urlRoot: 'disk',
        defaults:{
          channel:'0.0.0.0',
          parent:0,
          size:0
        }
    });
    return Disk;
});