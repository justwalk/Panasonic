define(['underscore', 'backbone'], function(_, Backbone) {
  var Home = Backbone.Model.extend({
    urlRoot: 'home',
    noIoBind: false
  });

  return Home;
});