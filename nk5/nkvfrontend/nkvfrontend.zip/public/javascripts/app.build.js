({
    appDir: "../",
    baseUrl: "javascripts",
    dir: "../../public",
    modules:[{name: "main_helper"}],
    mainConfigFile: "main.js",
    paths: {
        socketio: "empty:",
        msgFactory: "empty:",
        bootstrapDatatables: "empty:",
        locale: "empty:", 
        requireLib: "vendor/require/require"
    },
    optimize:'none',
    include:['requireLib']
})
