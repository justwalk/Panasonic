
exports.index = function(req, res){
	res.redirect('/sessions/new');
};


exports.new = function(req, res){
	res.render('sessions/new');
};
